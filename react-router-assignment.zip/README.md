# React Router Assignment
This is a basic React application demonstrating React Router with three pages: Home, About, and Contact.
